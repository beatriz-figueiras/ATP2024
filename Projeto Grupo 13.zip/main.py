from graph import *
from fun import *
import FreeSimpleGUI as sg 
import calendar 
from datetime import datetime 
import matplotlib.pyplot as plt
from io import BytesIO


def main():
    wprincipal()
main()